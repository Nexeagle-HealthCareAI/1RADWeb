/**
 * Tiny Express status API — exposes bridge state to the React dashboard.
 * Listens on BRIDGE_API_PORT (default 3001).
 * CORS is open so the local React app can reach it.
 */

const http = require('http');
const store = require('./store');
const logger = require('./logger');

const PORT = parseInt(process.env.BRIDGE_API_PORT || '3001', 10);

// Private Network Access (PNA) is a Chrome security policy that blocks
// HTTPS pages on a public origin (like the deployed Azure Static Web App)
// from reaching loopback / LAN addresses unless the local server explicitly
// opts in. Without `Access-Control-Allow-Private-Network: true` on both the
// preflight and the actual response, the browser fails the fetch with
// "Permission was denied for this request to access the loopback address
// space." — exactly the error the frontend was seeing.
const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Allow-Private-Network': 'true',
  // Pre-flight caching keeps the dashboard's 2-3s status polling cheap:
  // the browser caches the OPTIONS response for 24h instead of re-asking
  // before every GET.
  'Access-Control-Max-Age': '86400',
};

function json(res, data, status = 200) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    ...CORS_HEADERS,
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

let _processStudy = null;

const server = http.createServer((req, res) => {
  // Handle CORS pre-flight (incl. Chrome PNA). The browser sends
  // `Access-Control-Request-Private-Network: true` on the preflight when
  // the request crosses from a public origin into the loopback space;
  // returning `Access-Control-Allow-Private-Network: true` here is the
  // signal Chrome needs to allow the actual GET/POST.
  if (req.method === 'OPTIONS') {
    res.writeHead(204, CORS_HEADERS);
    res.end();
    return;
  }

  const url = req.url.split('?')[0];

  if (req.method === 'POST') {
    if (url === '/api/config') {
      let body = '';
      req.on('data', chunk => { body += chunk.toString(); });
      req.on('end', () => {
        try {
          const config = JSON.parse(body);
          store.setConfig(config);
          logger.info(`[API] Config updated: ${JSON.stringify(config)}`);
          json(res, { ok: true, config: store.getConfig() });
        } catch (e) {
          json(res, { error: 'Invalid JSON' }, 400);
        }
      });
      return;
    }

    if (url.startsWith('/api/upload/')) {
      const uid = url.split('/')[3];
      if (!uid) return json(res, { error: 'Missing UID' }, 400);

      logger.info(`[API] Manual upload triggered for ${uid}`);
      if (_processStudy) {
        _processStudy(uid).catch(err => logger.error(`[API] Manual upload failed: ${err.message}`));
      }
      json(res, { ok: true, message: 'Upload started' });
      return;
    }

    return json(res, { error: 'Not found' }, 404);
  }

  if (req.method !== 'GET') {
    json(res, { error: 'Method not allowed' }, 405);
    return;
  }

  if (url === '/api/status') {
    const stats = store.getStats();
    json(res, {
      ok: true,
      config: stats.config,
      lastChangeId: store.getLastChangeId(),
      uploaded: stats.uploaded,
      failed: stats.failed,
      pending: stats.pending,
      recent: stats.recent,
      timestamp: new Date().toISOString(),
    });
    return;
  }

  if (url === '/api/ping') {
    json(res, { ok: true, version: '1.0.0', timestamp: new Date().toISOString() });
    return;
  }

  json(res, { error: 'Not found' }, 404);
});

function startApi({ processStudy }) {
  _processStudy = processStudy;
  server.listen(PORT, '127.0.0.1', () => {
    logger.info(`[API] Status dashboard API running at http://localhost:${PORT}`);
  });
  server.on('error', (err) => {
    logger.warn(`[API] Could not start status API: ${err.message}`);
  });
}

module.exports = { startApi };
