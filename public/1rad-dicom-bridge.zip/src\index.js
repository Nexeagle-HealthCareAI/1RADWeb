require('dotenv').config();

const orthanc  = require('./orthanc');
const uploader = require('./uploader');
const matcher  = require('./matcher');
const store    = require('./store');
const logger   = require('./logger');
const { startApi } = require('./api');
const fs       = require('fs');
const os       = require('os');
const path     = require('path');

const POLL_INTERVAL  = parseInt(process.env.POLL_INTERVAL_SECONDS || '30', 10) * 1000;
const CONFIDENCE     = parseFloat(process.env.MATCH_CONFIDENCE_THRESHOLD || '0.6');

let polling = false;

function cleanupTempFiles() {
  const tmpDir = os.tmpdir();
  try {
    const files = fs.readdirSync(tmpDir);
    let deleted = 0;
    for (const file of files) {
      if (file.startsWith('nexegale_') && file.endsWith('.zip')) {
        fs.unlinkSync(path.join(tmpDir, file));
        deleted++;
      }
    }
    if (deleted > 0) {
      logger.info(`[CLEANUP] Deleted ${deleted} orphaned temp ZIP files from previous runs.`);
    }
  } catch (err) {
    logger.warn(`[CLEANUP] Failed to scan temp directory: ${err.message}`);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Process a single Orthanc study
// ─────────────────────────────────────────────────────────────────────────────
async function processStudy(studyUid) {
  // 1. Fetch and parse metadata from Orthanc
  const raw  = await orthanc.getStudy(studyUid);
  const meta = orthanc.parseStudyMeta(raw);

  logger.info(`[STUDY] ${meta.patientName} | ${meta.modality} | ${meta.studyDate} | ${meta.seriesCount} series`);

  if (!meta.patientName) {
    logger.warn(`[SKIP] Study ${studyUid} has no patient name — cannot match`);
    store.markFailed(studyUid, meta, 'Missing patient name in DICOM tags');
    return;
  }

  // 2. Search 1Rad for matching appointments
  const appointments = await uploader.searchAppointments(meta.patientName);
  logger.info(`[MATCH] Found ${appointments.length} appointment(s) for "${meta.patientName}"`);

  const result = matcher.findBestMatch(appointments, meta, CONFIDENCE);

  if (!result) {
    const msg = `No appointment matched (name="${meta.patientName}", modality=${meta.modality}, date=${meta.studyDate}, threshold=${CONFIDENCE})`;
    logger.warn(`[MATCH] ${msg}`);
    store.markFailed(studyUid, meta, msg);
    return;
  }

  const { appointment, confidence } = result;
  logger.info(
    `[MATCH] ✓ "${appointment.patientName}" — appointment ${appointment.appointmentId} — ` +
    `confidence ${(confidence * 100).toFixed(1)}%`
  );

  // 3. Download ZIP from Orthanc
  logger.info(`[DOWNLOAD] Downloading study from Orthanc...`);
  let zipPath = null;
  try {
    zipPath = await orthanc.downloadStudyZip(studyUid, (pct) => {
      if (pct > 0 && pct % 25 === 0) logger.info(`[DOWNLOAD] ${pct}%`);
    });
    logger.info(`[DOWNLOAD] Done → ${zipPath}`);

    // 4. Upload to 1Rad
    logger.info(`[UPLOAD] Uploading to appointment ${appointment.appointmentId}...`);
    const uploadRes = await uploader.uploadZip(appointment.appointmentId, zipPath);
    logger.info(`[UPLOAD] Done — response: ${JSON.stringify(uploadRes).slice(0, 120)}`);

    // 5. Update appointment status
    await uploader.markScanned(appointment.appointmentId);

    // 6. Record success in local store
    store.markProcessed(studyUid, appointment.appointmentId, meta, confidence);
    logger.info(`[DONE] Study ${studyUid} processed successfully ✓`);

  } finally {
    // Always clean up the temp ZIP
    if (zipPath && fs.existsSync(zipPath)) {
      fs.unlinkSync(zipPath);
      logger.debug(`[CLEANUP] Deleted temp ZIP`);
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Main poll cycle — reads Orthanc /changes, processes StableStudy events
// ─────────────────────────────────────────────────────────────────────────────
async function poll() {
  if (polling) return;
  polling = true;

  try {
    let lastId = store.getLastChangeId();
    let done   = false;
    let newStudies = 0;

    while (!done) {
      const result = await orthanc.getChanges(lastId, 100);
      const stableStudies = (result.Changes || []).filter(c => c.ChangeType === 'StableStudy');

      for (const change of stableStudies) {
        const uid = change.ID;

        if (store.isProcessed(uid)) {
          logger.debug(`[SKIP] Already processed: ${uid}`);
          continue;
        }

        newStudies++;
        logger.info(`[NEW] Stable study detected: ${uid}`);

        try {
          const config = store.getConfig();
          const rawMeta = await orthanc.getStudy(uid);
          const meta = orthanc.parseStudyMeta(rawMeta);

          const isModalityAllowed = config.autoModalities.length === 0 || config.autoModalities.includes(meta.modality);

          if (config.uploadMode === 'auto' && isModalityAllowed) {
            await processStudy(uid);
          } else {
            logger.info(`[PENDING] Study ${uid} waiting for manual upload (Mode: ${config.uploadMode}, Modality: ${meta.modality})`);
            store.markPending(uid, meta);
          }
        } catch (err) {
          // Fetch meta for failure record (best-effort)
          const meta = await orthanc.getStudy(uid)
            .then(s => orthanc.parseStudyMeta(s))
            .catch(() => null);
          store.markFailed(uid, meta, err.message);
          logger.error(`[ERROR] Study ${uid}: ${err.message}`);
        }
      }

      lastId = result.Last ?? lastId;
      store.setLastChangeId(lastId);
      done = result.Done !== false;
    }

    if (newStudies > 0) {
      const stats = store.getStats();
      logger.info(`[STATS] Uploaded: ${stats.uploaded} | Failed: ${stats.failed}`);
    }

  } catch (err) {
    logger.error(`[POLL ERROR] ${err.message}`);
  } finally {
    polling = false;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Boot sequence
//
// IMPORTANT — DO NOT process.exit() ON TRANSIENT FAILURES.
//
// When this bridge runs as a Windows Service (the install-service.js path),
// Windows starts the process under LocalSystem at boot. At boot, network
// stacks aren't always ready: VPN tunnels haven't come up, split-DNS hasn't
// resolved the API hostname, Orthanc may not have finished starting yet.
// The old code aborted with process.exit(1) on first failure. Windows sees
// a non-zero exit, marks the service "Stopped", restarts up to maxRestarts,
// then gives up — and the engineer finds the service flat-lined in
// services.msc with no idea why.
//
// The new behaviour: log the problem, mark the bridge as "not ready",
// schedule a background recovery loop that re-probes Orthanc + auth every
// few seconds with exponential backoff, and once both succeed, start the
// poll loop. The process stays alive throughout, so the Windows Service
// reports Running, and the bridge starts processing studies the moment the
// network is back — no human intervention needed.
// ─────────────────────────────────────────────────────────────────────────────

let bridgeReady = false;
let pollIntervalHandle = null;

// Heartbeat the recovery loop: 10s, 20s, 40s, 80s, capped at 300s (5 min).
function backoffMs(failures) {
  return Math.min(10_000 * Math.pow(2, failures), 5 * 60 * 1000);
}

async function probeOrthanc() {
  try {
    const ok = await orthanc.ping();
    if (ok) return { ok: true };
    return { ok: false, reason: 'Orthanc /system returned non-OK' };
  } catch (err) {
    return { ok: false, reason: err.message };
  }
}

async function probeAuth() {
  try {
    await uploader.authenticate();
    return { ok: true };
  } catch (err) {
    return { ok: false, reason: err.message };
  }
}

async function ensureReady() {
  if (bridgeReady) return true;

  const orthancRes = await probeOrthanc();
  if (!orthancRes.ok) {
    logger.warn(`[STARTUP] Orthanc not reachable yet: ${orthancRes.reason}`);
    return false;
  }
  logger.info('✓ Orthanc connected');

  const authRes = await probeAuth();
  if (!authRes.ok) {
    logger.warn(`[STARTUP] 1Rad auth not ready yet: ${authRes.reason}`);
    return false;
  }
  logger.info('✓ 1Rad API authenticated');

  bridgeReady = true;
  logger.info('────────────────────────────────────────────────');
  logger.info('Bridge is READY — starting poll loop');
  logger.info('────────────────────────────────────────────────');

  // Kick off the first poll, then schedule repeats.
  poll().catch(err => logger.error(`[POLL] First poll errored: ${err.message}`));
  if (pollIntervalHandle == null) {
    pollIntervalHandle = setInterval(() => {
      poll().catch(err => logger.error(`[POLL] Errored: ${err.message}`));
    }, POLL_INTERVAL);
  }
  return true;
}

async function recoveryLoop() {
  let failures = 0;
  // Loop forever — only exits if main process exits. Stays "Running" in
  // services.msc throughout the wait, which is the whole point.
  while (true) {
    const ready = await ensureReady();
    if (ready) {
      // Bridge is up. Slow the loop way down — it now serves as a watchdog
      // that re-probes once a minute. If either Orthanc or 1Rad falls over
      // mid-flight, the next poll() will surface the error; this loop
      // doesn't have to thrash.
      await new Promise(r => setTimeout(r, 60_000));
      // Re-probe lightly to recover quickly if connectivity returns after
      // a temporary loss.
      const stillOk = (await probeOrthanc()).ok && (await probeAuth()).ok;
      if (!stillOk && bridgeReady) {
        logger.warn('[WATCHDOG] Connectivity lost — entering recovery mode');
        bridgeReady = false;
        if (pollIntervalHandle) {
          clearInterval(pollIntervalHandle);
          pollIntervalHandle = null;
        }
      }
      continue;
    }
    const delay = backoffMs(failures);
    failures++;
    logger.info(`[STARTUP] Will retry in ${Math.round(delay / 1000)}s (attempt ${failures})`);
    await new Promise(r => setTimeout(r, delay));
  }
}

async function main() {
  logger.info('════════════════════════════════════════════════');
  logger.info('   NexEgale DICOM Bridge  v1.0.0');
  logger.info('════════════════════════════════════════════════');
  logger.info(`Orthanc URL  : ${process.env.ORTHANC_URL}`);
  logger.info(`1Rad API     : ${process.env.ONERAD_API_URL}`);
  logger.info(`Poll interval: ${POLL_INTERVAL / 1000}s`);
  logger.info(`Confidence   : ${CONFIDENCE}`);
  logger.info('────────────────────────────────────────────────');

  cleanupTempFiles();

  // Start the status API FIRST and unconditionally. The dashboard needs to
  // be reachable even while the bridge is in the "waiting for network"
  // state — that's exactly when an operator most needs visibility.
  startApi({ processStudy });

  // Fire-and-forget the recovery loop. The process stays alive on its
  // event-loop timers (setInterval inside ensureReady + the recovery
  // sleeps), so Windows sees a Running service.
  recoveryLoop().catch(err => {
    // recoveryLoop() shouldn't throw — it has its own try/catch around
    // each probe — but if it does, log and let the process keep running
    // rather than exiting. A dead service is worse than a noisy one.
    logger.error(`[FATAL] Recovery loop crashed: ${err.message}`);
  });
}

// Handle graceful shutdown
process.on('SIGTERM', () => { logger.info('SIGTERM received — shutting down'); process.exit(0); });
process.on('SIGINT',  () => { logger.info('SIGINT received — shutting down');  process.exit(0); });
process.on('uncaughtException', (err) => logger.error(`Uncaught: ${err.message}`));
process.on('unhandledRejection', (err) => logger.error(`Unhandled: ${err?.message || err}`));

main();
